package com.example.musicplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;


public class MainActivity extends AppCompatActivity {
MediaPlayer playmusicc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
playmusicc=MediaPlayer.create(this,R.raw.bossbitch);
    }
        public void playmu(View v){
        playmusicc.start();
        }
        public void pausemu(View v){
        if (playmusicc.isPlaying())
        playmusicc.pause();
        }

}

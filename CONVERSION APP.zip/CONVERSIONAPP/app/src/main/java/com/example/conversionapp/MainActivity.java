package com.example.conversionapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonconvmilestokm = (Button) findViewById(R.id.buttonconvmilestokm);
        buttonconvmilestokm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText textmoxmiles = (EditText) findViewById(R.id.editTextmiles);
                EditText textmoxkm = (EditText) findViewById(R.id.editTextkm);
               double vmiles= Double.valueOf(textmoxmiles.getText().toString());
               double vkm = vmiles / 0.62137;
                DecimalFormat formatval = new DecimalFormat("##.##");
               textmoxkm.setText(formatval.format(vkm));

            }
        });
        Button buttonconvkmtomiles = (Button) findViewById(R.id.buttonconvkmtomiles);
        buttonconvkmtomiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText textmoxmiles = (EditText) findViewById(R.id.editTextmiles);
                EditText textmoxkm = (EditText) findViewById(R.id.editTextkm);
                double vkm= Double.valueOf(textmoxkm.getText().toString());
                double vmiles = vkm * 0.62137;
                DecimalFormat formatval = new DecimalFormat("##.##");
                textmoxmiles.setText(formatval.format(vmiles));

            }
        });
    }
}